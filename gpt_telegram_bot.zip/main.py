import os
import logging
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters
import openai

openai.api_key = os.getenv("OPENAI_KEY")

logging.basicConfig(level=logging.INFO)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Привет! Я GPT-психолог. Напиши, что тебя тревожит.")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_message = update.message.text
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[{"role": "user", "content": user_message}],
            temperature=0.7
        )
        reply = response['choices'][0]['message']['content']
    except Exception as e:
        reply = f"Ошибка от OpenAI: {e}"
    await update.message.reply_text(reply)
